sensors =[]
guage_value=0