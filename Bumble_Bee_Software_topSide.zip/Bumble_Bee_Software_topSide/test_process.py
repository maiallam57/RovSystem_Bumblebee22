import time
for i in range(0,5):
    print(str(time.time()))
    time.sleep(1)